
```mermaid
stateDiagram
    direction LR
ISE_MnT_Version_API --> Cisco_Identity_Services_Engine
Cisco_Identity_Services_Engine --> Type_of_Node_2
state Type_of_Node_2{
        Version v3_1_0_518
}
```