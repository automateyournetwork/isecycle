
```mermaid
erDiagram
    ISE_MnT_Version_API |o--|{ Cisco_Identity_Services_Engine : Type_of_Node_1
    Cisco_Identity_Services_Engine {
        Version v3_1_0_518
    }
```