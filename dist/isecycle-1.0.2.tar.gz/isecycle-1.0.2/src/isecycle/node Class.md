
```mermaid
classDiagram
class ise_1{
ID: fa0ddee0-1094-11ec-9899-005056bf1031
URL: https://10.10.20.77/ers/config/node/fa0ddee0-1094-11ec-9899-005056bf1031
}
class ise_2{
ID: cb574c10-abe1-11ec-afaa-7a2b76f8718c
URL: https://10.10.20.77/ers/config/node/cb574c10-abe1-11ec-afaa-7a2b76f8718c
}
class ise_3{
ID: feb37d90-abe1-11ec-afaa-7a2b76f8718c
URL: https://10.10.20.77/ers/config/node/feb37d90-abe1-11ec-afaa-7a2b76f8718c
}
class ise_4{
ID: 28b657c0-abe2-11ec-afaa-7a2b76f8718c
URL: https://10.10.20.77/ers/config/node/28b657c0-abe2-11ec-afaa-7a2b76f8718c
}

```