
# ISE ERS Node API
## Name
### ise-1
#### Node ID: fa0ddee0-1094-11ec-9899-005056bf1031
#### [URL](https://10.10.20.77/ers/config/node/fa0ddee0-1094-11ec-9899-005056bf1031)
### ise-2
#### Node ID: cb574c10-abe1-11ec-afaa-7a2b76f8718c
#### [URL](https://10.10.20.77/ers/config/node/cb574c10-abe1-11ec-afaa-7a2b76f8718c)
### ise-3
#### Node ID: feb37d90-abe1-11ec-afaa-7a2b76f8718c
#### [URL](https://10.10.20.77/ers/config/node/feb37d90-abe1-11ec-afaa-7a2b76f8718c)
### ise-4
#### Node ID: 28b657c0-abe2-11ec-afaa-7a2b76f8718c
#### [URL](https://10.10.20.77/ers/config/node/28b657c0-abe2-11ec-afaa-7a2b76f8718c)