
```mermaid
erDiagram
    ISE_ERS_Node_API |o--|{ ise_1 : ID_fa0ddee0-1094-11ec-9899-005056bf1031
    ise_1 {
        URL https://10.10.20.77/ers/config/node/fa0ddee0-1094-11ec-9899-005056bf1031
    }
```
```mermaid
erDiagram
    ISE_ERS_Node_API |o--|{ ise_2 : ID_cb574c10-abe1-11ec-afaa-7a2b76f8718c
    ise_2 {
        URL https://10.10.20.77/ers/config/node/cb574c10-abe1-11ec-afaa-7a2b76f8718c
    }
```
```mermaid
erDiagram
    ISE_ERS_Node_API |o--|{ ise_3 : ID_feb37d90-abe1-11ec-afaa-7a2b76f8718c
    ise_3 {
        URL https://10.10.20.77/ers/config/node/feb37d90-abe1-11ec-afaa-7a2b76f8718c
    }
```
```mermaid
erDiagram
    ISE_ERS_Node_API |o--|{ ise_4 : ID_28b657c0-abe2-11ec-afaa-7a2b76f8718c
    ise_4 {
        URL https://10.10.20.77/ers/config/node/28b657c0-abe2-11ec-afaa-7a2b76f8718c
    }
```