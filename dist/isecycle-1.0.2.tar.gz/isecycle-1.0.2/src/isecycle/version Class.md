
```mermaid
classDiagram
class Cisco_Identity_Services_Engine{
Type of Node: 1 
Version: 3.1.0.518
}
```