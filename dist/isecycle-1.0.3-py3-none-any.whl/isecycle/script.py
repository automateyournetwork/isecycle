from .isecycle import cli
def run():
    cli()